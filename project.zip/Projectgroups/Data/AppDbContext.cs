﻿using Microsoft.EntityFrameworkCore;
using Projectgroups.Models;

namespace Projectgroups.Data
{
    public class AppDbContext : DbContext
    {

        public DbSet<Event> Events { get; set; }


        public AppDbContext()
        {

            this.Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            optionsBuilder.UseSqlite("Data Source=EventDatabase.db");
        }
    }
}