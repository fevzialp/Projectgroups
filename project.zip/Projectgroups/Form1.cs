namespace Projectgroups
{
    public partial class Form1 : Form
    {
        public string CurrentRole; 


        public Form1(string role)
        {
            InitializeComponent();
            this.CurrentRole = role; 
            AdjustAccessByRole();    
        }
    



        private void AdjustAccessByRole()
        {
            if (CurrentRole == "Customer")
            {

                btnAdmin.Visible = false;

                UC_Customer uc = new UC_Customer();
                ShowPage(uc);
            }
            else if (CurrentRole == "Admin")
            {

                btnAdmin.Visible = true;
            }
        }



        public void ShowSidebar()
        {
            pnlSidebar.Visible = true;
            pnlContent.Controls.Clear(); 
        }
        private void pnlContent_Paint(object sender, PaintEventArgs e)
        {

        }
        private void ShowPage(UserControl page)
        {

            pnlContent.Controls.Clear();

           
            page.Dock = DockStyle.Fill;


            pnlContent.Controls.Add(page);
        }
        private void btnAdmin_Click(object sender, EventArgs e)
        {


            UC_Admin adminPage = new UC_Admin();

            ShowPage(adminPage);
        }

        private void pnlContent_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        public void CloseAdminAndShowMenu()
        {
            pnlSidebar.Visible = true; 
            pnlContent.Controls.Clear(); 
        }

        private void pnlSidebar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            UC_Customer customerPage = new UC_Customer();
            ShowPage(customerPage); 

        }

        private void btnAbout_Click(object sender, EventArgs e)
        {
            UC_About aboutPage = new UC_About();
            ShowPage(aboutPage);
        }
    }
}
