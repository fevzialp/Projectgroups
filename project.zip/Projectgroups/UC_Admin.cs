﻿using Projectgroups.Data;
using Projectgroups.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.IO;

namespace Projectgroups
{
    public partial class UC_Admin : UserControl
    {
        public UC_Admin()
        {
            InitializeComponent();
            // Sayfa oluşturulur oluşturulmaz verileri yükler
            RefreshEventGrid();
        }

        private void UC_Admin_Load(object sender, EventArgs e)
        {
            var mainForm = (Form1)this.ParentForm;
            if (mainForm != null)
            {
                mainForm.pnlSidebar.Visible = false;
            }

            // Sayfa her yüklendiğinde verilerin güncel olduğundan emin oluruz
            RefreshEventGrid();
        }

        // Merkezi Veri Yükleme Metodu
        private void RefreshEventGrid()
        {
            try
            {
                using (var db = new AppDbContext())
                {
                    var events = db.Events.ToList();
                    dgvEvents.DataSource = events;

                    if (dgvEvents.Columns["Id"] != null)
                        dgvEvents.Columns["Id"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message, "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text) ||
                string.IsNullOrWhiteSpace(txtPrice.Text) ||
                string.IsNullOrWhiteSpace(txtCapacity.Text))
            {
                MessageBox.Show("Please fill in all required fields.", "Validation Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var db = new AppDbContext())
                {
                    var newEvent = new Event
                    {
                        Title = txtTitle.Text,
                        Price = Convert.ToDecimal(txtPrice.Text),
                        Capacity = Convert.ToInt32(txtCapacity.Text),
                        Category = "General",
                        EventDate = DateTime.Now.AddDays(7),
                        SoldTickets = 0
                    };

                    db.Events.Add(newEvent);
                    db.SaveChanges();

                    MessageBox.Show("Event recorded successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    RefreshEventGrid();
                    ClearInputFields(); // Kayıttan sonra kutuları temizler
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Save error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // --- YENİ: CLEAR BUTONU ---
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearInputFields();
        }

        // Merkezi Temizleme Metodu
        private void ClearInputFields()
        {
            txtTitle.Clear();
            txtPrice.Clear();
            txtCapacity.Clear();
            // Odaklanmayı tekrar ilk kutuya alalım
            txtTitle.Focus();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (dgvEvents.SelectedRows.Count > 0)
            {
                DialogResult dialog = MessageBox.Show("Delete this event permanently?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (dialog == DialogResult.Yes)
                {
                    try
                    {
                        int selectedEventId = (int)dgvEvents.SelectedRows[0].Cells["Id"].Value;

                        using (var db = new AppDbContext())
                        {
                            var eventToDelete = db.Events.Find(selectedEventId);
                            if (eventToDelete != null)
                            {
                                db.Events.Remove(eventToDelete);
                                db.SaveChanges();

                                MessageBox.Show("Event removed successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                RefreshEventGrid();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Deletion error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnExportJson_Click(object sender, EventArgs e)
        {
            using (var db = new AppDbContext())
            {
                var eventList = db.Events.ToList();
                string json = JsonConvert.SerializeObject(eventList, Formatting.Indented);

                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.Filter = "JSON Files (*.json)|*.json";
                saveDialog.FileName = "Events_Backup.json";

                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(saveDialog.FileName, json);
                    MessageBox.Show("Data exported successfully.", "Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnImportJson_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "JSON Files (*.json)|*.json";

            if (openDialog.ShowDialog() == DialogResult.OK)
            {
                string json = File.ReadAllText(openDialog.FileName);
                var importedEvents = JsonConvert.DeserializeObject<List<Event>>(json);

                if (importedEvents != null)
                {
                    using (var db = new AppDbContext())
                    {
                        db.Events.AddRange(importedEvents);
                        db.SaveChanges();
                        RefreshEventGrid();
                        MessageBox.Show($"{importedEvents.Count} events imported.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (this.ParentForm is Form1 mainForm)
            {
                mainForm.CloseAdminAndShowMenu();
            }
        }

        private void btnClear_Click_1(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Are you sure you want to delete ALL events from the database? This action cannot be undone!",
                                          "Danger - Bulk Delete",
                                          MessageBoxButtons.YesNo,
                                          MessageBoxIcon.Stop);

            if (dialog == DialogResult.Yes)
            {
                try
                {
                    using (var db = new AppDbContext())
                    {
                        var allEvents = db.Events.ToList();

                        if (allEvents.Count > 0)
                        {
                            db.Events.RemoveRange(allEvents);
                            db.SaveChanges();

                            MessageBox.Show("All event records have been successfully deleted.", "Database Cleared", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            RefreshEventGrid();
                        }
                        else
                        {
                            MessageBox.Show("The database is already empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while clearing the database: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dgvEvents_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}