﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Projectgroups.Data;
using Projectgroups.Models;

namespace Projectgroups
{
    public partial class UC_Customer : UserControl
    {
        public UC_Customer()
        {
            InitializeComponent();
            LoadEventsToGrid();
        }

        /// <summary>
        /// Loads all events from the database and updates the DataGridView.
        /// </summary>
        private void LoadEventsToGrid()
        {
            using (var db = new AppDbContext())
            {
                dgvEventsCustomer.DataSource = db.Events.ToList();

                // Hide the Id column for a professional and cleaner user interface
                if (dgvEventsCustomer.Columns["Id"] != null)
                {
                    dgvEventsCustomer.Columns["Id"].Visible = false;
                }
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            using (var db = new AppDbContext())
            {
                var lowerText = txtSearch.Text.ToLower();
                var filtered = db.Events
                    .Where(x => x.Title.ToLower().Contains(lowerText))
                    .ToList();

                dgvEventsCustomer.DataSource = filtered;
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (this.ParentForm is Form1 mainForm)
            {
                mainForm.CloseAdminAndShowMenu();
            }
        }

        private void btnBuy_Click_1(object sender, EventArgs e)
        {
            if (dgvEventsCustomer.SelectedRows.Count > 0)
            {
                // Retrieve the Id of the selected event
                int eventId = Convert.ToInt32(dgvEventsCustomer.SelectedRows[0].Cells["Id"].Value);

                using (var db = new AppDbContext())
                {
                    var selectedEvent = db.Events.Find(eventId);

                    if (selectedEvent != null)
                    {
                        if (selectedEvent.Capacity > 0)
                        {
                            // Update event capacity and statistics
                            selectedEvent.Capacity -= 1;
                            selectedEvent.SoldTickets += 1;
                            db.SaveChanges();

                            MessageBox.Show($"Ticket purchased successfully for: {selectedEvent.Title}\nRemaining Capacity: {selectedEvent.Capacity}",
                                            "Transaction Successful",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);

                            LoadEventsToGrid();
                        }
                        else
                        {
                            MessageBox.Show("We are sorry, this event is currently sold out.",
                                            "Capacity Reached",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select an event from the table to proceed with the purchase.",
                                "Selection Required",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (var db = new AppDbContext())
            {
                string keyword = txtSearch.Text.ToLower();

                var results = db.Events
                    .Where(x => x.Title.ToLower().Contains(keyword))
                    .ToList();

                dgvEventsCustomer.DataSource = results;

                if (results.Count == 0)
                {
                    MessageBox.Show("No events found matching your search criteria.",
                                    "No Results Found",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                }
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (dgvEventsCustomer.SelectedRows.Count > 0)
            {
                DialogResult dialog = MessageBox.Show("Are you sure you want to delete this event record permanently?",
                                                      "Confirm Deletion",
                                                      MessageBoxButtons.YesNo,
                                                      MessageBoxIcon.Question);

                if (dialog == DialogResult.Yes)
                {
                    try
                    {
                        int selectedEventId = (int)dgvEventsCustomer.SelectedRows[0].Cells["Id"].Value;

                        using (var db = new AppDbContext())
                        {
                            var eventToDelete = db.Events.Find(selectedEventId);

                            if (eventToDelete != null)
                            {
                                db.Events.Remove(eventToDelete);
                                db.SaveChanges();

                                MessageBox.Show("The event record has been successfully deleted.",
                                                "Deletion Successful",
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Information);

                                LoadEventsToGrid();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An unexpected error occurred during the deletion process: " + ex.Message,
                                        "Error",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select an event from the table to perform the deletion.",
                                "Selection Required",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
            }
        }

        private void dgvEventsCustomer_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}