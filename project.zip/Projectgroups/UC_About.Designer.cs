﻿namespace Projectgroups
{
    partial class UC_About
    {
        /// <summary> 
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Bileşen Tasarımcısı üretimi kod

        /// <summary> 
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            rtbAbout = new RichTextBox();
            btnThanks = new Button();
            SuspendLayout();
            // 
            // rtbAbout
            // 
            rtbAbout.Dock = DockStyle.Fill;
            rtbAbout.Location = new Point(0, 0);
            rtbAbout.Name = "rtbAbout";
            rtbAbout.Size = new Size(694, 505);
            rtbAbout.TabIndex = 0;
            rtbAbout.Text = "";
            // 
            // btnThanks
            // 
            btnThanks.BackColor = SystemColors.ActiveCaption;
            btnThanks.Location = new Point(269, 384);
            btnThanks.Name = "btnThanks";
            btnThanks.Size = new Size(114, 38);
            btnThanks.TabIndex = 1;
            btnThanks.Text = "THANK YOU";
            btnThanks.UseVisualStyleBackColor = false;
            btnThanks.Click += btnThanks_Click;
            // 
            // UC_About
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(btnThanks);
            Controls.Add(rtbAbout);
            Name = "UC_About";
            Size = new Size(694, 505);
            ResumeLayout(false);
        }

        #endregion
        private RichTextBox rtbAbout;
        private Button btnThanks;
    }
}
