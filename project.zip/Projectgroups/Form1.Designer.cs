﻿namespace Projectgroups
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pnlSidebar = new Panel();
            btnExit = new Button();
            btnAbout = new Button();
            btnCustomer = new Button();
            btnAdmin = new Button();
            pnlContent = new Panel();
            pnlSidebar.SuspendLayout();
            SuspendLayout();
            // 
            // pnlSidebar
            // 
            pnlSidebar.BackColor = SystemColors.ActiveCaption;
            pnlSidebar.Controls.Add(btnExit);
            pnlSidebar.Controls.Add(btnAbout);
            pnlSidebar.Controls.Add(btnCustomer);
            pnlSidebar.Controls.Add(btnAdmin);
            pnlSidebar.Dock = DockStyle.Left;
            pnlSidebar.Location = new Point(0, 0);
            pnlSidebar.Name = "pnlSidebar";
            pnlSidebar.Size = new Size(200, 502);
            pnlSidebar.TabIndex = 2;
            pnlSidebar.Paint += pnlSidebar_Paint;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(16, 221);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(122, 23);
            btnExit.TabIndex = 3;
            btnExit.Text = "Logout";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // btnAbout
            // 
            btnAbout.Location = new Point(16, 163);
            btnAbout.Name = "btnAbout";
            btnAbout.Size = new Size(122, 23);
            btnAbout.TabIndex = 2;
            btnAbout.Text = "About-Help";
            btnAbout.UseVisualStyleBackColor = true;
            btnAbout.Click += btnAbout_Click;
            // 
            // btnCustomer
            // 
            btnCustomer.Location = new Point(16, 108);
            btnCustomer.Name = "btnCustomer";
            btnCustomer.Size = new Size(122, 23);
            btnCustomer.TabIndex = 1;
            btnCustomer.Text = "Ticket Booking";
            btnCustomer.UseVisualStyleBackColor = true;
            btnCustomer.Click += btnCustomer_Click;
            // 
            // btnAdmin
            // 
            btnAdmin.Location = new Point(16, 48);
            btnAdmin.Name = "btnAdmin";
            btnAdmin.Size = new Size(122, 23);
            btnAdmin.TabIndex = 0;
            btnAdmin.Text = "Admin Dashboard";
            btnAdmin.UseVisualStyleBackColor = true;
            btnAdmin.Click += btnAdmin_Click;
            // 
            // pnlContent
            // 
            pnlContent.BackColor = SystemColors.ButtonFace;
            pnlContent.Dock = DockStyle.Fill;
            pnlContent.Location = new Point(200, 0);
            pnlContent.Name = "pnlContent";
            pnlContent.Size = new Size(611, 502);
            pnlContent.TabIndex = 3;
            pnlContent.Paint += pnlContent_Paint_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(811, 502);
            Controls.Add(pnlContent);
            Controls.Add(pnlSidebar);
            Name = "Form1";
            Text = "Event Ticket Management System";
            pnlSidebar.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Button btnExit;
        private Button btnAbout;
        private Button btnCustomer;
        private Button btnAdmin;
        private Panel pnlContent;
        public Panel pnlSidebar;
    }
}
