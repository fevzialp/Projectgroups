﻿namespace Projectgroups
{
    partial class UC_Admin
    {

        private System.ComponentModel.IContainer components = null;

        /// <summary> 

        /// </summary>
        
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Bileşen Tasarımcısı üretimi kod

        /// <summary> 

        /// </summary>
        private void InitializeComponent()
        {
            lblEventTitle = new Label();
            lblPrice = new Label();
            lblCapacity = new Label();
            txtPrice = new TextBox();
            txtTitle = new TextBox();
            txtCapacity = new TextBox();
            btnAdd = new Button();
            dgvEvents = new DataGridView();
            btnBack = new Button();
            btnRemove = new Button();
            btnExportJson = new Button();
            btnImportJson = new Button();
            btnClear = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvEvents).BeginInit();
            SuspendLayout();
            // 
            // lblEventTitle
            // 
            lblEventTitle.AutoSize = true;
            lblEventTitle.Location = new Point(30, 46);
            lblEventTitle.Name = "lblEventTitle";
            lblEventTitle.Size = new Size(62, 15);
            lblEventTitle.TabIndex = 0;
            lblEventTitle.Text = "Event Title";
            // 
            // lblPrice
            // 
            lblPrice.AutoSize = true;
            lblPrice.Location = new Point(30, 93);
            lblPrice.Name = "lblPrice";
            lblPrice.Size = new Size(33, 15);
            lblPrice.TabIndex = 1;
            lblPrice.Text = "Price";
            // 
            // lblCapacity
            // 
            lblCapacity.AutoSize = true;
            lblCapacity.Location = new Point(30, 139);
            lblCapacity.Name = "lblCapacity";
            lblCapacity.Size = new Size(53, 15);
            lblCapacity.TabIndex = 2;
            lblCapacity.Text = "Capacity";
            // 
            // txtPrice
            // 
            txtPrice.Location = new Point(111, 90);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(136, 23);
            txtPrice.TabIndex = 3;
            // 
            // txtTitle
            // 
            txtTitle.Location = new Point(111, 46);
            txtTitle.Name = "txtTitle";
            txtTitle.Size = new Size(136, 23);
            txtTitle.TabIndex = 4;
            // 
            // txtCapacity
            // 
            txtCapacity.Location = new Point(111, 139);
            txtCapacity.Name = "txtCapacity";
            txtCapacity.Size = new Size(136, 23);
            txtCapacity.TabIndex = 5;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(3, 205);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(99, 23);
            btnAdd.TabIndex = 6;
            btnAdd.Text = "Add Event";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // dgvEvents
            // 
            dgvEvents.BackgroundColor = SystemColors.ActiveCaption;
            dgvEvents.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvEvents.Location = new Point(308, 19);
            dgvEvents.Name = "dgvEvents";
            dgvEvents.ReadOnly = true;
            dgvEvents.Size = new Size(379, 316);
            dgvEvents.TabIndex = 7;
            dgvEvents.CellContentClick += dgvEvents_CellContentClick;
            // 
            // btnBack
            // 
            btnBack.Location = new Point(125, 253);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(99, 23);
            btnBack.TabIndex = 8;
            btnBack.Text = "Back to Menu";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(3, 253);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(99, 23);
            btnRemove.TabIndex = 9;
            btnRemove.Text = "Remove Event";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // btnExportJson
            // 
            btnExportJson.Location = new Point(542, 350);
            btnExportJson.Name = "btnExportJson";
            btnExportJson.Size = new Size(75, 23);
            btnExportJson.TabIndex = 10;
            btnExportJson.Text = "Export";
            btnExportJson.UseVisualStyleBackColor = true;
            btnExportJson.Click += btnExportJson_Click;
            // 
            // btnImportJson
            // 
            btnImportJson.Location = new Point(374, 350);
            btnImportJson.Name = "btnImportJson";
            btnImportJson.Size = new Size(75, 23);
            btnImportJson.TabIndex = 11;
            btnImportJson.Text = "Import";
            btnImportJson.UseVisualStyleBackColor = true;
            btnImportJson.Click += btnImportJson_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(125, 205);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(99, 23);
            btnClear.TabIndex = 12;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click_1;
            // 
            // UC_Admin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(btnClear);
            Controls.Add(btnImportJson);
            Controls.Add(btnExportJson);
            Controls.Add(btnRemove);
            Controls.Add(btnBack);
            Controls.Add(dgvEvents);
            Controls.Add(btnAdd);
            Controls.Add(txtCapacity);
            Controls.Add(txtTitle);
            Controls.Add(txtPrice);
            Controls.Add(lblCapacity);
            Controls.Add(lblPrice);
            Controls.Add(lblEventTitle);
            Name = "UC_Admin";
            Size = new Size(774, 523);
            ((System.ComponentModel.ISupportInitialize)dgvEvents).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblEventTitle;
        private Label lblPrice;
        private Label lblCapacity;
        private TextBox txtPrice;
        private TextBox txtTitle;
        private TextBox txtCapacity;
        private Button btnAdd;
        private DataGridView dgvEvents;
        private Button btnBack;
        private Button btnRemove;
        private Button btnExportJson;
        private Button btnImportJson;
        private Button btnClear;
    }
}
