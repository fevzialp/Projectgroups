﻿using System;
using System.Windows.Forms;

namespace Projectgroups
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            string role = cmbRole.SelectedItem?.ToString();

            // Admin Authentication
            if (role == "Admin" && username == "admin" && password == "1234")
            {
                OpenMainForm("Admin");
            }
            // Customer Authentication
            else if (role == "Customer" && username == "user" && password == "1234")
            {
                OpenMainForm("Customer");
            }
            // Failed Authentication
            else
            {
                MessageBox.Show("Invalid username, password, or role selection. Please try again.",
                                "Login Failed",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        private void OpenMainForm(string role)
        {
            // Initializes Form1 with the selected user role
            Form1 main = new Form1(role);
            main.Show();
            this.Hide();
        }
    }
}