﻿namespace Projectgroups
{
    partial class UC_Customer
    {
        /// <summary> 

        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 

        /// </summary>
 
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Bileşen Tasarımcısı üretimi kod

        /// <summary> 

        /// </summary>
        private void InitializeComponent()
        {
            dgvEventsCustomer = new DataGridView();
            txtSearch = new TextBox();
            label1 = new Label();
            btnBuyTicket = new Button();
            btnBack = new Button();
            btnBuy = new Button();
            btnSearch = new Button();
            btnRemove = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvEventsCustomer).BeginInit();
            SuspendLayout();
            // 
            // dgvEventsCustomer
            // 
            dgvEventsCustomer.BackgroundColor = SystemColors.ActiveCaption;
            dgvEventsCustomer.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvEventsCustomer.Location = new Point(337, 39);
            dgvEventsCustomer.MultiSelect = false;
            dgvEventsCustomer.Name = "dgvEventsCustomer";
            dgvEventsCustomer.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvEventsCustomer.Size = new Size(368, 288);
            dgvEventsCustomer.TabIndex = 0;
            dgvEventsCustomer.CellContentClick += dgvEventsCustomer_CellContentClick;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(170, 75);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(100, 23);
            txtSearch.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(36, 78);
            label1.Name = "label1";
            label1.Size = new Size(128, 15);
            label1.TabIndex = 2;
            label1.Text = "Search by Event Name:";
            // 
            // btnBuyTicket
            // 
            btnBuyTicket.Location = new Point(36, 171);
            btnBuyTicket.Name = "btnBuyTicket";
            btnBuyTicket.Size = new Size(116, 23);
            btnBuyTicket.TabIndex = 3;
            btnBuyTicket.Text = "Ticket Booking";
            btnBuyTicket.UseVisualStyleBackColor = true;
            btnBuyTicket.Click += btnBuy_Click_1;
            // 
            // btnBack
            // 
            btnBack.Location = new Point(170, 171);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(100, 23);
            btnBack.TabIndex = 4;
            btnBack.Text = "Back to Menu";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // btnBuy
            // 
            btnBuy.Location = new Point(47, 221);
            btnBuy.Name = "btnBuy";
            btnBuy.Size = new Size(75, 23);
            btnBuy.TabIndex = 5;
            btnBuy.Text = "Buy";
            btnBuy.UseVisualStyleBackColor = true;
            btnBuy.Click += btnBuy_Click_1;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(186, 221);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(75, 23);
            btnSearch.TabIndex = 6;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(115, 270);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(75, 23);
            btnRemove.TabIndex = 7;
            btnRemove.Text = "Remove";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // UC_Customer
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(btnRemove);
            Controls.Add(btnSearch);
            Controls.Add(btnBuy);
            Controls.Add(btnBack);
            Controls.Add(btnBuyTicket);
            Controls.Add(label1);
            Controls.Add(txtSearch);
            Controls.Add(dgvEventsCustomer);
            Name = "UC_Customer";
            Size = new Size(756, 537);
            ((System.ComponentModel.ISupportInitialize)dgvEventsCustomer).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvEventsCustomer;
        private TextBox txtSearch;
        private Label label1;
        private Button btnBuyTicket;
        private Button btnBack;
        private Button btnBuy;
        private Button btnSearch;
        private Button btnRemove;
    }
}
