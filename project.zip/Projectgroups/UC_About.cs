﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projectgroups
{
    public partial class UC_About : UserControl
    {
        public UC_About()
        {
            InitializeComponent();
            
            rtbAbout.Dock = DockStyle.Fill;
            FillAboutDetails();
        }

        private void FillAboutDetails()
        {
            
            rtbAbout.Clear();
            rtbAbout.ReadOnly = true; 
            rtbAbout.BackColor = Color.White;

            
            rtbAbout.SelectionFont = new Font("Segoe UI", 14, FontStyle.Bold);
            rtbAbout.SelectionColor = Color.Navy;
            rtbAbout.AppendText("ABOUT - HELP CENTER\n");
            rtbAbout.AppendText("==================================================\n\n");

            
            rtbAbout.SelectionFont = new Font("Segoe UI", 11, FontStyle.Bold);
            rtbAbout.AppendText("1. TECHNICAL INFORMATION\n");

            rtbAbout.SelectionFont = new Font("Segoe UI", 10, FontStyle.Regular);
            rtbAbout.AppendText("Project Name: ");
            rtbAbout.AppendText("Event Management & Ticket Booking System\n");
            rtbAbout.AppendText("Developed By: ");
            rtbAbout.AppendText("[Fevzi Alp Aydın,Eren Tunc,Ugur Biyiklioglu]\n");
            rtbAbout.AppendText("Database: ");
            rtbAbout.AppendText("SQLite with Entity Framework Core\n");
            rtbAbout.AppendText("Architecture: ");
            rtbAbout.AppendText("C# WinForms with UserControl Management\n\n");

            
            rtbAbout.SelectionFont = new Font("Segoe UI", 11, FontStyle.Bold);
            rtbAbout.AppendText("2. USER GUIDE\n");

            rtbAbout.SelectionFont = new Font("Segoe UI", 10, FontStyle.Regular);
            rtbAbout.SelectionBullet = true; 
            rtbAbout.AppendText("Admin Role: Can add new events, delete existing ones, and manage the event database.\n");
            rtbAbout.AppendText("Customer Role: Can search for specific events, view details, and purchase tickets instantly.\n");
            rtbAbout.AppendText("Real-time Updates: Ticket capacities are updated in real-time across the database.\n");
            rtbAbout.SelectionBullet = false; 
            rtbAbout.AppendText("\n");


            rtbAbout.SelectionFont = new Font("Segoe UI", 11, FontStyle.Bold);
            rtbAbout.AppendText("3. SUPPORT & VERSION\n");

            rtbAbout.SelectionFont = new Font("Segoe UI", 10, FontStyle.Regular);
            rtbAbout.AppendText("Version: 1.0 (Final Project)\n");
            rtbAbout.AppendText("Support: For any technical issues, please contact the developer via student mail.\n");
        }

        private void btnThanks_Click(object sender, EventArgs e)
        {
            MessageBox.Show("✔ Thanks for your attention!", "Finish", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
