﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Projectgroups.Models
{
    public class Event
    {
        [Key]
        public int Id { get; set; } // Veritabanı bunu otomatik artıracak

        public string Title { get; set; } // Etkinlik adı

        public string Category { get; set; } = "General"; // Boş kalırsa hata vermemesi için varsayılan değer

        public DateTime EventDate { get; set; } = DateTime.Now; // Tarih

        public decimal Price { get; set; } // Fiyat

        public int Capacity { get; set; } // Kapasite

        public int SoldTickets { get; set; } = 0; // Başlangıçta 0 bilet satıldı
    }
}